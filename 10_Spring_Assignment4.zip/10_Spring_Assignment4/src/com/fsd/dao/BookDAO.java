package com.fsd.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.fsd.entity.Book;

@Repository
@Transactional
public class BookDAO extends AbstractJpaDAO< Book >{

	@PersistenceContext
	EntityManager entityManager;
	
	
	public BookDAO()
	{
		setClazz(Book.class );
	}
	
	@Transactional
	public boolean addBook(Book book, int subjectId) {
		boolean flag=false;
		book.setSubjectId(subjectId);
		entityManager.persist(book);
		//create(book);
		flag=true;
		return flag;
	}
	
	@Transactional
	public boolean deleteBook(int bookId) {
		boolean flag=false;
		Book book=findOne(Long.valueOf(bookId));
		if(null!=book) {
			delete(book);
			flag=true;
		}
	
		else {
			flag=false;
		}
		
		
		return flag;
	}
	
	@Transactional
	public Book searchBook(int bookId) {
		
		Book book=new Book();
		book=findOne(Long.valueOf(bookId));
		
		return book;
	}
}
