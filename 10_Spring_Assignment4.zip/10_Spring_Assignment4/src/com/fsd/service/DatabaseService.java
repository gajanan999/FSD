package com.fsd.service;

import org.springframework.stereotype.Service;

import com.fsd.dao.DatabaseDAO;

@Service
public class DatabaseService {

	
	
	
}
