package com.fsd.controller;

import java.io.EOFException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.HashSet;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.fsd.dao.DatabaseDAO;
import com.fsd.dao.SubjectDAO;
import com.fsd.entity.Book;
import com.fsd.entity.Subject;
import com.fsd.utility.GeneralUtility;

@Controller
public class SubjectController {
	
	@Autowired
	SubjectDAO subjectDAO;

	@RequestMapping(value = "/deleteSubject", method = RequestMethod.POST)
	public String deleteSubject(@RequestParam("subjectId") int subjectId, Model model) throws IOException {
		boolean subjectDeleted=false;
		//subjectDeleted=databaseDAO.deleteSubject(subjectId);
		subjectDeleted=subjectDAO.deleteSubject(subjectId);
		
		if (subjectDeleted) {
			model.addAttribute("message", "Subject has been deleted");
		} else {
			model.addAttribute("message", "Subject not Found");
		}
		
		
		return "deleteSubject";
	}
	
	@RequestMapping(value = "/searchSubject", method = RequestMethod.POST)
	public String searchSubject(@RequestParam("subjectId") int subjectId, Model model) throws IOException {
		Subject sub=new Subject();
		Set<Subject> foundSubjects = new HashSet<>();
		sub=subjectDAO.searchSubject(subjectId);
		//sub=databaseDAO.searchSubject(subjectId);
		foundSubjects.add(sub);
		model.addAttribute("subjects", foundSubjects);
		return "searchSubject";
		
	}
	
}
