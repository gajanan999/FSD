package com.fsd.dao;

import com.fsd.vo.Book;
import com.fsd.vo.Subject;

public interface DatabaseDAO {

	boolean addSubject(Subject subject);
	boolean addBook(Book book,int subjectId);
	Boolean deletSubject(int subjectId);
	Boolean deletBook(int bookId);
	Subject searchSubject(int subjectId);
	Book searchBook(int bookId);
	
}
