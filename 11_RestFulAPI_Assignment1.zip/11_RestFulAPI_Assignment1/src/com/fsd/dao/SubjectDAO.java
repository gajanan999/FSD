package com.fsd.dao;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.fsd.entity.Subject;

@Repository
@Transactional
public class SubjectDAO  extends AbstractJpaDAO< Subject >{

	@PersistenceContext
	EntityManager entityManager;
	
	
	public SubjectDAO()
	{
		setClazz(Subject.class );
	}
	
	@Transactional
	public boolean addSubject(Subject subject, int subjectId) {
		boolean flag=false;
		entityManager.persist(subject);
		//create(subject);
		flag=true;
		return flag;
	}
	
	@Transactional
	public boolean deleteSubject(int subjectId) {
		boolean flag=false;
		Subject subject=findOne(Long.valueOf(subjectId));
		if(null!=subject) {
			delete(subject);
			flag=true;
		}else {
			flag=false;
		}
		
		return flag;
	}
	@Transactional
	public Subject searchSubject(int subjectId) {
		Subject subject=new Subject();
		subject=findOne(Long.valueOf(subjectId));
		
		
		return subject;
	}
	
	
	@Transactional
	public List<Subject> searchSubjectByDuration(int durationInHours) {
		List<Subject> subjects=new ArrayList<>();
		//subject=findOne(Long.valueOf(subjectId));
		subjects=(List<Subject>)entityManager.createQuery("select s from Subject s where s.durationInHours=:durationInHours")
				.setParameter("durationInHours", durationInHours)
				.getResultList();
		
		return subjects;
	}
	
}
