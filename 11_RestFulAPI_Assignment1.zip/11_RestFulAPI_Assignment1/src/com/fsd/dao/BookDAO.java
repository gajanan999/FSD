package com.fsd.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.PathVariable;

import com.fsd.entity.Book;

@Repository
@Transactional
public class BookDAO extends AbstractJpaDAO< Book >{

	@PersistenceContext
	EntityManager entityManager;
	
	
	public BookDAO()
	{
		setClazz(Book.class );
	}
	
	public List<Book> getAllBooks(){
		List<Book> books=new ArrayList<>();
		books=findAll();
		
		return books;
	}
	
	public Book getBookById(@PathVariable("bookId") int bookId) {
		
		Book book=findOne(Long.valueOf(bookId));
		return book;
	}
	
	public Book deleteBookById(@PathVariable("bookId") int bookId) {
		Book book=findOne(Long.valueOf(bookId));
		delete(book);
		return book;
		
	}
	
	@Transactional
	public boolean addBook(Book book, int subjectId) {
		boolean flag=false;
		book.setSubjectId(subjectId);
		entityManager.persist(book);
		//create(book);
		flag=true;
		return flag;
	}
	
	@Transactional
	public boolean deleteBook(int bookId) {
		boolean flag=false;
		Book book=findOne(Long.valueOf(bookId));
		if(null!=book) {
			delete(book);
			flag=true;
		}
	
		else {
			flag=false;
		}
		
		
		return flag;
	}
	
	@Transactional
	public Book searchBook(int bookId) {
		
		Book book=new Book();
		book=findOne(Long.valueOf(bookId));
		
		return book;
	}
	
	@Transactional
	public List<Book> searchBookByTitle(String title) {
		
		Book book=new Book();
		List<Book> books=new ArrayList<>();
		//subject=findOne(Long.valueOf(subjectId));
		books=(List<Book>)entityManager.createQuery("select s from Book s where s.title=:title")
				.setParameter("title", title)
				.getResultList();
		
		return books;
	}

	public Book put(Book book) {
	
		entityManager.merge( book );
		return book;
	}
	
	public Book createBook(Book book) {
		
		entityManager.persist(book);
		return book;
	}
	
}
