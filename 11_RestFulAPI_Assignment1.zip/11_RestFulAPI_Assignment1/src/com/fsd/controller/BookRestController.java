package com.fsd.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.fsd.dao.BookDAO;
import com.fsd.entity.Book;

@Controller
@RequestMapping("/book")
public class BookRestController {
	
	@Autowired
	BookDAO bookDAO;

	@GetMapping("/getAllBooks")
	@ResponseBody
	public List<Book> getAllBooks(){
		return bookDAO.getAllBooks();
	}
	
	@GetMapping("/getBookById/{bookId}")
	@ResponseBody
	public Book getBookById(@PathVariable("bookId") int bookId) {
		return bookDAO.getBookById(bookId);
	}
	
	@DeleteMapping("/deleteBookById/{bookId}")
	@ResponseBody
	public Book deleteBookById(@PathVariable("bookId") int bookId) {
		Book book=bookDAO.getBookById(bookId);
		bookDAO.deleteBookById(bookId);
		return book;
	}
	
	@RequestMapping(value = "/create", method = RequestMethod.POST)
	@ResponseBody
	public Book create(@RequestBody  Book book) {
		book=bookDAO.createBook(book);
		return book;
	}
	
	@PutMapping("/modify/{bookId}")
	@ResponseBody
	public Book modify(@RequestBody  Book book,@PathVariable("bookId") int bookId) {
		book=bookDAO.put(book);
		return book;
	}
	
	
}
