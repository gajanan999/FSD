package com.fsd.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import org.springframework.context.annotation.Lazy;

@Entity
@Table(name="subject")
@NamedQueries({
	@NamedQuery(name = "Subject.searchSubjectByDuration", query = "select s from Subject s where s.durationInHours= ?1")
})
public class Subject implements Serializable {
	
	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 1L;
	/**
	 * Variables
	 */
	
	@Id
	@Column(name="subjectid")
	private long subjectId;
	
	@Column(name="subtitle")
	private String subTitle;
	
	@Column(name="durationInHours")
	private int durationInHours;
	

	public Subject() {
		
	}
	
	/**
	 * Methods
	 * 
	 */
	public long getSubjectId() {
		return subjectId;
	}
	public void setSubjectId(long subjectId) {
		this.subjectId = subjectId;
	}
	
	public String getSubTitle() {
		return subTitle;
	}

	public void setSubTitle(String subTitle) {
		this.subTitle = subTitle;
	}

	public int getDurationInHours() {
		return durationInHours;
	}
	public void setDurationInHours(int durationInHours) {
		this.durationInHours = durationInHours;
	}
	/*public Set<Book> getReferences() {
		return references;
	}
	public void setReferences(Set<Book> references) {
		this.references = references;
	}*/

	@Override
	public String toString() {
		return "Subject [subjectId=" + subjectId + ", subTitle=" + subTitle + ", durationInHours=" + durationInHours
				+ "]";
	}
	
	
	
}
