package com.fsd.dao;




import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.hibernate.ObjectNotFoundException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.fsd.entity.Book;
import com.fsd.entity.Subject;

@Repository("databaseDAO")	
public class DatabaseDAO {
	
	
	@PersistenceContext
	EntityManager entityManager;

	

	public boolean addSubject(Subject subject) {
		boolean flag=false;
		
	    
		
		return flag;
	}

	
	public boolean addBook(Book book, int subjectId) {
		boolean flag=false;
		
		return flag;
	}
	
	@Transactional
	public Subject getSubjectById(long subjectId) {
		Subject subject=null;
		
		return subject;
	}


	public Boolean deleteSubject(int subjectId) {
		Subject subject=getSubjectById(subjectId);
		
		return true;
	}
	
	@Transactional
	public Book getBookById(long bookId) {
		Book book=null;
		
		return book;
	}

	
	public Boolean deletBook(int bookId) {
		Book book=getBookById(bookId);
		
		return true;
	}

	
	public Subject searchSubject(int subjectId) {
		
		return getSubjectById(subjectId);
	}

	
	public Book searchBook(int bookId) {
		// TODO Auto-generated method stub
		return getBookById(bookId);
	}

	
	
	/*public List<Book> getSortedBooksByTitle() {
		List<Book> books=new ArrayList<>();
		Session session=null;
		
		  try{

			//	SessionFactory factory = ConnectionFactory.getSessionFactory();
			    session = factory.openSession();  
			    Transaction t = session.beginTransaction();  
			    String hql = "FROM Book b ORDER BY b.title ASC";
				Query query = session.createQuery(hql);
			    books=(ArrayList<Book>)query.getResultList();
			    session.close(); 
			}catch(Exception e) {
				if(null != session.getTransaction()) {
					session.getTransaction().rollback();
				}
				System.out.println(e);
				session.close(); 
			}
		return books;
	}

	
	

	public List<Subject> getSortedSubjectsByTitle() {
		List<Subject> subjects=new ArrayList<>();
		Session session=null;
		
		  try{

				//SessionFactory factory = ConnectionFactory.getSessionFactory();
			    session = factory.openSession();  
			    Transaction t = session.beginTransaction();  
			    String hql = "FROM Subject b ORDER BY b.subTitle ASC";
				Query query = session.createQuery(hql);
			    subjects=(ArrayList<Subject>)query.getResultList();
			    session.close(); 
			}catch(Exception e) {
				if(null != session.getTransaction()) {
					session.getTransaction().rollback();
				}
				System.out.println(e);
				session.close(); 
			}
		return subjects;
	}


	public List<Book> getSortedBooksByPublishDate() {
		List<Book> books=new ArrayList<>();
		Session session=null;
		
		  try{

			//	SessionFactory factory = ConnectionFactory.getSessionFactory();
			    session = factory.openSession();  
			    Transaction t = session.beginTransaction();  
			    String hql = "FROM Book b ORDER BY b.publishDate ASC";
				Query query = session.createQuery(hql);
			    books=(ArrayList<Book>)query.getResultList();
			    session.close(); 
			}catch(Exception e) {
				if(null != session.getTransaction()) {
					session.getTransaction().rollback();
				}
				System.out.println(e);
				session.close(); 
			}
		return books;
	}
	*/
}
