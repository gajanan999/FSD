package com.fsd.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.fsd.dao.SubjectDAO;
import com.fsd.dao.SubjectRepository;
import com.fsd.entity.Subject;

@Controller
public class SubjectController {
	
	@Autowired
	SubjectDAO subjectDAO;
	
	@Autowired
	SubjectRepository subjectRepository;

	@RequestMapping(value = "/deleteSubject", method = RequestMethod.POST)
	public String deleteSubject(@RequestParam("subjectId") int subjectId, Model model) throws IOException {
		boolean subjectDeleted=false;
		//subjectDeleted=databaseDAO.deleteSubject(subjectId);
		//subjectDeleted=subjectDAO.deleteSubject(subjectId);
		subjectRepository.deleteById(Long.valueOf(subjectId));
		
		if (subjectDeleted) {
			model.addAttribute("message", "Subject has been deleted");
		} else {
			model.addAttribute("message", "Subject not Found");
		}
		
		
		return "deleteSubject";
	}
	
	@RequestMapping(value = "/searchSubject", method = RequestMethod.POST)
	public String searchSubject(@RequestParam("subjectId") int subjectId, Model model) throws IOException {
		Optional<Subject> sub;
		Set<Subject> foundSubjects = new HashSet<>();
		//sub=subjectDAO.searchSubject(subjectId);
		System.out.println(subjectId);
		sub=subjectRepository.findById(Long.valueOf(subjectId));
		//sub=databaseDAO.searchSubject(subjectId);e
		
		foundSubjects.add(sub.get());
		model.addAttribute("subjects", foundSubjects);
		return "searchSubject";
		
	}
	
	@RequestMapping(value = "/searchSubjectByDuration", method = RequestMethod.POST)
	public String searchSubjectByDuration(@RequestParam("durationInHours") int durationInHours, Model model) throws IOException {
		Subject sub=new Subject();
		List<Subject> foundSubjects = new ArrayList<>();
		
		//foundSubjects=subjectDAO.searchSubjectByDuration(durationInHours);
		System.out.println(durationInHours);
		foundSubjects=subjectRepository.searchSubjectByDuration(durationInHours);
		
		model.addAttribute("subjects", foundSubjects);
		return "searchSubjectByDuration";
		
	}
	
}
