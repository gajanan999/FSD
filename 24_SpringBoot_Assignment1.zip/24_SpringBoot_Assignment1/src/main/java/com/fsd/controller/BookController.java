package com.fsd.controller;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.fsd.dao.BookDAO;
import com.fsd.dao.SubjectDAO;
import com.fsd.entity.Book;
import com.fsd.entity.Subject;

@Controller
public class BookController {

	@Autowired
	BookDAO bookDAO;
	
	@Autowired
	SubjectDAO subjectDAO;
	
	
	@RequestMapping(value = "/deleteBook", method = RequestMethod.POST)
	public String deleteBook(@RequestParam("bookId") int bookId, Model model) throws IOException {
		
		
		boolean bookDeleted=false;
		bookDeleted=bookDAO.deleteBook(bookId);
		if (bookDeleted) {
			model.addAttribute("message", "Book has been deleted");
		} else {
			model.addAttribute("message", "Book not Found");
		}
		return "deleteBook";
	}

	@RequestMapping(value = "/searchBook", method = RequestMethod.POST)
	public String searchBook(@RequestParam("bookId") int bookId, Model model) throws IOException {
		Set<Book> books = new HashSet<>();
		//Book book=databaseDAO.searchBook(bookId);

		Book book=bookDAO.searchBook(bookId);
		
		books.add(book);
		model.addAttribute("books", books);

		return "searchBook";
	}
	
	@RequestMapping(value = "/searchBookByTitle", method = RequestMethod.POST)
	public String searchBook(@RequestParam("title") String title, Model model) throws IOException {
		List<Book> books = new ArrayList<>();
		//Book book=databaseDAO.searchBook(bookId);

		books=bookDAO.searchBookByTitle(title);
		
		
		model.addAttribute("books", books);

		return "searchBook";
	}

	@RequestMapping(value = "/addBook", method = RequestMethod.POST)
	public String addBook(@RequestParam("bookId") int bookId, @RequestParam("title") String title,
			@RequestParam("price") double price, @RequestParam("volume") int volume,
			@RequestParam("publishDate") /*@DateTimeFormat(pattern = "dd/MM/yyyy") Date*/ String date,
			@RequestParam("subjectId") int subjectId,
			@RequestParam("subjectTitle") String subjectTitle,
			@RequestParam("durationInHours") int durationInHours, Model model) throws ParseException {
		
		Book book = new Book();
		book.setBookId(bookId);
		book.setPrice(price);
		SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-dd-MM");
		
		book.setPublishDate(new java.sql.Date(sdf1.parse(date).getTime()));
		book.setTitle(title);
		book.setVolume(volume);
		System.out.println(book.toString());
		
		Subject subject=new Subject();
		subject.setSubjectId(subjectId);
		subject.setSubTitle(subjectTitle);
		subject.setDurationInHours(durationInHours);
		//databaseDAO.addSubject(subject);
		//databaseDAO.addBook(book,(int)subject.getSubjectId());
		subjectDAO.addSubject(subject,(int)subject.getSubjectId());
		bookDAO.addBook(book,(int)subject.getSubjectId());
		
		model.addAttribute("message", "Book & Subject has been successfully saved");
		return "addBook";
	}

}
