package com.fsd.dao;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import org.hibernate.SessionFactory;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;

import com.mysql.jdbc.Driver;

public class ConnectionFactory {

	
	public static final String URL = "jdbc:mysql://localhost:3306/fsd";
    public static final String USER = "root";
    public static final String PASS = "gajanan";

    public static SessionFactory factory;
    
    /**
     * Get a connection to database
     * @return Connection object
     */
    public static Connection getConnection()
    {
      try {
          DriverManager.registerDriver(new Driver());
          return DriverManager.getConnection(URL, USER, PASS);
      } catch (SQLException ex) {
          throw new RuntimeException("Error connecting to the database", ex);
      }
    }

    public static Metadata getMetaData() {
    	StandardServiceRegistry ssr = new StandardServiceRegistryBuilder().configure("hibernate.cfg.xml").build();  
        Metadata meta = new MetadataSources(ssr).getMetadataBuilder().build();  
        return meta;
    }
    
    public static SessionFactory getSessionFactory() {
    	if(factory==null) {
    		factory = ConnectionFactory.getMetaData().getSessionFactoryBuilder().build();  
    	}
    	
    	return factory;
    }
    
}
