package com.fsd.dao;

import javax.transaction.Transactional;

import org.hibernate.ObjectNotFoundException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.fsd.vo.Book;
import com.fsd.vo.Subject;

public class HibernateDatabaseDAOImpl implements HibernateDatabaseDAO {

	@Override
	public boolean addSubject(Subject subject) {
		boolean flag=false;
		  SessionFactory factory = ConnectionFactory.getSessionFactory();  
	      Session session = factory.openSession();  
	      Transaction t = session.beginTransaction();  
	      session.save(subject); 
	      t.commit(); 
	      System.out.println("successfully saved");    
         // factory.close();  
          session.close(); 
		  flag=true;
		
		return flag;
	}

	@Override
	public boolean addBook(Book book, int subjectId) {
		boolean flag=false;
		SessionFactory factory =ConnectionFactory.getSessionFactory();;  
	      Session session = factory.openSession();  
	      Transaction t = session.beginTransaction();  
	      book.setSubjectId(subjectId);
	      session.save(book); 
	      t.commit(); 
	      System.out.println("successfully saved");    
       // factory.close();  
        session.close(); 
		  flag=true;
		return flag;
	}
	
	@Transactional
	public Subject getSubjectById(long subjectId) {
		Subject subject=null;
		Session session=null;
		try {

		SessionFactory factory = ConnectionFactory.getSessionFactory();
	    session = factory.openSession();  
	    Transaction t = session.beginTransaction();  
	    subject=session.load(Subject.class,subjectId);
	   // factory.close();
	    session.close(); 
		}catch(Exception e) {
			if(null != session.getTransaction()) {
				session.getTransaction().rollback();
			}
			if(e instanceof ObjectNotFoundException) {
				System.out.println("Subject not found");
			}
			else
			System.out.println(e);
			session.close(); 
		}
		  
        
		return subject;
	}

	@Override
	public Boolean deletSubject(int subjectId) {
		Subject subject=getSubjectById(subjectId);
		SessionFactory factory =ConnectionFactory.getSessionFactory();
	    Session session = factory.openSession();  
	    Transaction t = session.beginTransaction(); 
		
		session.delete(subject);
		t.commit();
        session.close(); 
		return true;
	}
	
	@Transactional
	public Book getBookById(long bookId) {
		Book book=null;
		Session session=null;
		try {

		SessionFactory factory = ConnectionFactory.getSessionFactory();
	    session = factory.openSession();  
	    Transaction t = session.beginTransaction();  
	    book=session.load(Book.class,bookId);
	    //factory.close();  
        session.close(); 
		}catch(Exception e) {
			if(null != session.getTransaction()) {
				session.getTransaction().rollback();
			}
			if(e instanceof ObjectNotFoundException) {
				System.out.println("Book not found");
			}else
				System.out.println(e);
			session.close(); 
			
		}
		return book;
	}

	@Override
	public Boolean deletBook(int bookId) {
		Book book=getBookById(bookId);
		SessionFactory factory = ConnectionFactory.getMetaData().getSessionFactoryBuilder().build();  
	    Session session = factory.openSession();  
	    Transaction t = session.beginTransaction(); 
		
		session.delete(book);
		t.commit();
		//factory.close();  
        session.close(); 
		return true;
	}

	@Override
	public Subject searchSubject(int subjectId) {
		
		return getSubjectById(subjectId);
	}

	@Override
	public Book searchBook(int bookId) {
		// TODO Auto-generated method stub
		return getBookById(bookId);
	}

}
