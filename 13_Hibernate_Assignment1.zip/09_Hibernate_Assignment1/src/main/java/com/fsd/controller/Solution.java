package com.fsd.controller;

import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.sql.Date;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.ListIterator;
import java.util.Scanner;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import com.fsd.dao.DatabaseDAO;
import com.fsd.dao.DatabaseDAOImple;
import com.fsd.dao.HibernateDatabaseDAO;
import com.fsd.dao.HibernateDatabaseDAOImpl;
import com.fsd.vo.Book;
import com.fsd.vo.Subject;

public class Solution {

	public static void main(String[] args) {
		Scanner scanner = null;
		char c='\0';
		System.out.println("Welcome to Menu Driven Console base Application Operation using JDBC DAO");
		try{
			
			scanner=new Scanner(System.in);
			
			do{
			System.out.println("A.Add a Subject");
			System.out.println("B.Add a Book");
			System.out.println("C.Delete a Subject");
			System.out.println("D.Delete a Book");
			System.out.println("E.Search for a Book");
			System.out.println("F.Search for a Subject");
			System.out.println("G.Sort Book By Title");
			System.out.println("H.Sort Subject By Subject Title");
			System.out.println("I.Sort Books by publish Date");
			System.out.println("J.Exit");
			DatabaseDAO databaseDAO=new DatabaseDAOImple();
			HibernateDatabaseDAO hibernatedatabaseDAO=new HibernateDatabaseDAOImpl();
			char choice=scanner.next().charAt(0);
			switch(choice){
			case 'A':
				Subject subject=getSubject(scanner);
				
				boolean flag=hibernatedatabaseDAO.addSubject(subject);
				if(flag) {
					System.out.println("Subject has been added successfully");
				}else {
					System.out.println("Unfortunatly , subject has not been added");
				}
				break;
			case 'B':
				System.out.println("Enter the subject Id for which you want to add the book");
				int id=scanner.nextInt();
				Book book=getBook(scanner);
				if(hibernatedatabaseDAO.addBook(book,id)) {
					System.out.println("Book has been added successfully");
				}else {
					System.out.println("Unfortunatly , Book has not been added");
				}
				
				break;
			case 'C':
				System.out.println("*********  Delete the Subject **********");
				System.out.println("Enter the subject Id for which you want to Delete");
				int subjectId=scanner.nextInt();
				if(hibernatedatabaseDAO.deletSubject(subjectId)) {
					System.out.println("Subject has been deleted successfully");
				}else {
					System.out.println("Unfortunatly , Subject has not been deleted");
				}
				break;
			case 'D':
				
				System.out.println("*********  Delete the Book **********");
				System.out.println("Enter the Book Id for which you want to Delete");
				int bookId=scanner.nextInt();
				if(hibernatedatabaseDAO.deletBook(bookId)) {
					System.out.println("Book has been deleted successfully");
				}else {
					System.out.println("Unfortunatly , Book has not been deleted");
				}
				break;
			case 'E':
				
				System.out.println("********* Search for Book **********");
				System.out.println("Enter the book Id for which you want to search");
				int bookIdforSearch=scanner.nextInt();
				Book searchedBook=hibernatedatabaseDAO.searchBook(bookIdforSearch);
				if(null!=searchedBook) {
					System.out.println("Book Details are");
					System.out.println(searchedBook.toString());
				}else {
					System.out.println("Book not found");
				}
				break;
			case 'F':
				System.out.println("********* Search for Subject **********");
				System.out.println("Enter the Subject Id for which you want to search");
				int subjectIdforSearch=scanner.nextInt();
				Subject searchedSubject=hibernatedatabaseDAO.searchSubject(subjectIdforSearch);
				if(null!=searchedSubject) {
					System.out.println("Subject Details are");
					System.out.println(searchedSubject.toString());
				}else {
					System.out.println("Subject not found");
				}
				break;
			case 'G':
				System.out.println("********* Sort Book By Title **********");
				List<Book> listBook=databaseDAO.getAllBooks();
				Stream<Book> strBooks=listBook.stream().sorted(new Comparator<Book>() {
					   public int compare(Book s1, Book s2) {
						return s1.getTitle().compareTo(s2.getTitle());
					   }
					}); 
				
				List<Book> strBooks1=strBooks.collect(Collectors.toList());
				for(Book bookG:strBooks1) {
					System.out.println(bookG.toString());
				}
				break;
			case 'H':
				System.out.println("********* Sort Subject By Subject Title **********");
				List<Subject> listSubject=databaseDAO.getAllSubjects();
				Stream<Subject> strSubjects=listSubject.stream().sorted(new Comparator<Subject>() {
					   public int compare(Subject s1, Subject s2) {
						return s1.getSubTitile().compareTo(s2.getSubTitile());
					   }
					}); 
				
				List<Subject> strSubjects1=strSubjects.collect(Collectors.toList());
				for(Subject subjectH:strSubjects1) {
					System.out.println(subjectH.toString());
				}
				
				break;
			case 'I':
				System.out.println("********* Sort Books by publish Date **********");
				List<Book> listBookI=databaseDAO.getAllBooks();
				Stream<Book> strBooksI=listBookI.stream().sorted(new Comparator<Book>() {
					   public int compare(Book s1, Book s2) {
						return s1.getPublishdDate().compareTo(s2.getPublishdDate());
					   }
					}); 
				
				List<Book> strBooks1I=strBooksI.collect(Collectors.toList());
				for(Book bookG:strBooks1I) {
					System.out.println(bookG.toString());
				}
				
				break;
			case 'J':
				System.exit(0);
				break;
			
			}
			
			
			System.out.println("Code executed until here");
			System.out.println("Enter Y to continue and N for exit");
			c=scanner.next().charAt(0);
			scanner.nextLine();
			}while(c=='Y');
			
		}catch(Exception e){
			System.out.println(e+" "+e.getMessage());
		}finally{
			scanner.close();
		}

	}
	
	
	public static ObjectInputStream getObjectInputStream(){
		FileInputStream fi;
		ObjectInputStream oi=null ;
		try {
			fi = new FileInputStream(new File("binary.ser"));
			oi = new ObjectInputStream(fi);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return oi;
	}
	
	
	public static ObjectOutputStream getObjectOutputStream(){
		FileOutputStream f;
		ObjectOutputStream o=null;
		try {
			f = new FileOutputStream(new File("binary.ser"));
			o = new ObjectOutputStream(f);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return o;
	}
	
	public static Subject getSubject(Scanner scanner){
		
		System.out.println("Enter the Subject Details");
		System.out.println("Enter the Subject ID");
		int id=scanner.nextInt();scanner.nextLine();
		System.out.println("Enter the Subtitle");
		String subTitle=scanner.nextLine();
		System.out.println("Enter the duration In hours");
		int duration=scanner.nextInt();
		/*System.out.println("Enter how many books do you want to add");
		int books=scanner.nextInt();
		Set<Book> listOfBook=new HashSet<>();
		while(books!=0){
			Book book=getBook(scanner);
			listOfBook.add(book);
			books--;
		}*/
		Subject subject=new Subject();
		subject.setDurationInHours(duration);
		//subject.setReferences(listOfBook);
		subject.setSubjectId(id);
		subject.setSubTitile(subTitle);
		return subject;
	}

	
	public static Book getBook(Scanner scanner){
		
		System.out.println("Enter the Book Details");
		System.out.println("Enter the Book ID");
		long id=scanner.nextLong();scanner.nextLine();
		System.out.println("Enter the Title");
		String title=scanner.nextLine();
		System.out.println("Enter the price");
		double price=scanner.nextDouble();
		System.out.println("Enter the Volume");
		int volume=scanner.nextInt();scanner.nextLine();
		System.out.println("Enter the Publish Date (dd/MM/yyyy)");
		String date=scanner.next();
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("d/MM/yyyy");
		//convert String to LocalDate
		LocalDate localDate = LocalDate.parse(date, formatter);
		Book book=new Book();
		book.setBookId(id);
		book.setPrice(price);
		book.setPublishdDate(Date.valueOf(localDate));
		book.setTitle(title);
		book.setVolume(volume);
		return book;
	}

}
