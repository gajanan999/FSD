package com.fsd.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.sql.Date;

import com.fsd.vo.Book;
import com.fsd.vo.Subject;
import com.mysql.jdbc.exceptions.jdbc4.MySQLIntegrityConstraintViolationException;

public class DatabaseDAOImple implements DatabaseDAO {

	public boolean addSubject(Subject subject) {
		Connection connection = ConnectionFactory.getConnection();
		try {
			PreparedStatement ps = connection.prepareStatement("INSERT INTO subject VALUES (?, ?, ?)");
			ps.setLong(1, subject.getSubjectId());
			ps.setString(2, subject.getSubTitile());
			ps.setInt(3, subject.getDurationInHours());
			int i = ps.executeUpdate();
			if (i == 1) {
				return true;
			}
		} catch (SQLException ex) {
			ex.printStackTrace();
		}
		return false;

	}

	public boolean addBook(Book book, int subjectId) {
		// TODO Auto-generated method stub
		Connection connection = ConnectionFactory.getConnection();
		try {
			PreparedStatement ps = connection.prepareStatement("INSERT INTO book VALUES (?, ?, ?, ?, ?, ?)");
			ps.setLong(1, book.getBookId());
			ps.setString(2, book.getTitle());
			ps.setDouble(3, book.getPrice());
			ps.setInt(4, book.getVolume());
			Date date = Date.valueOf(book.getPublishdDate());
			ps.setDate(5, date);
			ps.setInt(6, subjectId);
			int i = ps.executeUpdate();
			if (i == 1) {
				return true;
			}
		} catch (SQLException ex) {
			ex.printStackTrace();
		}
		return false;

	}

	public Boolean deletSubject(int subjectId) {
		Connection connection = ConnectionFactory.getConnection();
		try {

			Statement stmt = connection.createStatement();
			int i = stmt.executeUpdate("DELETE FROM subject WHERE subjectid=" + subjectId);
			if (i == 1) {
				return true;
			}
		} catch (SQLException ex) {
			if(ex instanceof MySQLIntegrityConstraintViolationException) {
				System.out.println("You can not delete the subject until and unless there is book available for this subject");
				System.out.println("Please delete the book first and then delete the subject");
			}
			//ex.printStackTrace();
		}
		return false;
	}

	public Boolean deletBook(int bookId) {
		Connection connection = ConnectionFactory.getConnection();
		try {

			Statement stmt = connection.createStatement();
			int i = stmt.executeUpdate("DELETE FROM book WHERE bookid=" + bookId);
			if (i == 1) {
				return true;
			}
		} catch (SQLException ex) {
			ex.printStackTrace();
		}
		return false;
	}

	public Subject searchSubject(int subjectId) {
		Subject subject=null;
		Connection connection = ConnectionFactory.getConnection();
		

		try {
			Statement stmt = connection.createStatement();
			ResultSet rs = stmt.executeQuery("SELECT * FROM subject WHERE subjectid=" + subjectId);
			Set<Book> books=new HashSet<>();
			 if(rs.next())
	            {
	                subject=new Subject();
	                subject.setSubjectId(rs.getInt("subjectid") );
	                subject.setSubTitile(rs.getString("subtitle"));
	                subject.setDurationInHours(rs.getInt("durationinhours"));
	               
	             
	            }
			 
			 ResultSet rs1 = stmt.executeQuery("SELECT * FROM book WHERE subjectid=" + subjectId);
			 while(rs1.next()) {
	             Book b=extractBookFromRS(rs1);
	             books.add(b);
			 }
			   
			 subject.setReferences(books);
             
             return subject;
			
		} catch (SQLException ex) {
			ex.printStackTrace();
		}
		return subject;
	}

	private Book extractBookFromRS(ResultSet rs) {
		Book book=null;
		 try {
			 book=new Book();
			 book.setBookId(rs.getInt("bookid"));
			 book.setPrice(rs.getDouble("price"));
	         book.setTitle(rs.getString("title"));
	         book.setVolume(rs.getInt("volume"));
	         book.setPublishdDate(rs.getDate("publishdate").toLocalDate());
		         
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
       
		return book;
	}

	public Book searchBook(int bookId) {
		Book book=null;
		Connection connection = ConnectionFactory.getConnection();
		

		try {
			Statement stmt = connection.createStatement();
			ResultSet rs = stmt.executeQuery("SELECT * FROM book WHERE bookid=" + bookId);
			 if(rs.next())
	            {
	                book=new Book();
	                book.setBookId(rs.getInt("bookid"));
	                book.setPrice(rs.getDouble("price"));
	                book.setTitle(rs.getString("title"));
	                book.setVolume(rs.getInt("volume"));
	                book.setPublishdDate(rs.getDate("publishdate").toLocalDate());
	                
	                return book;
	            }
			
		} catch (SQLException ex) {
			ex.printStackTrace();
		}
		return book;
	}

	@Override
	public List<Book> getAllBooks() {
		Connection connection = ConnectionFactory.getConnection();
		List<Book> books=new ArrayList<Book>();
		try {
			Statement stmt = connection.createStatement();
			ResultSet rs = stmt.executeQuery("SELECT * FROM book ");
			while(rs.next()) {
	             Book b=extractBookFromRS(rs);
	             books.add(b);
			 }
			return books;
		} catch (SQLException ex) {
			ex.printStackTrace();
		}
		return books;
	}

	@Override
	public List<Subject> getAllSubjects() {
		Connection connection = ConnectionFactory.getConnection();
		List<Subject> subjects=new ArrayList<Subject>();
		try {
			Statement stmt = connection.createStatement();
			ResultSet rs = stmt.executeQuery("SELECT * FROM subject ");
			
				while(rs.next()) {
						Subject subject=new Subject();
		                subject.setSubjectId(rs.getInt("subjectid") );
		                subject.setSubTitile(rs.getString("subtitle"));
		                subject.setDurationInHours(rs.getInt("durationinhours"));
		                Set<Book> books=new HashSet<>();
		
		   			/* ResultSet rs1 = stmt.executeQuery("SELECT * FROM book WHERE subjectid=" + subject.getSubjectId());
		   			 while(rs1.next()) {
		   	             Book b=extractBookFromRS(rs1);
		   	             books.add(b);
		   			 }*/
		   			   
		   			// subject.setReferences(books);
		   			subjects.add(subject);
				 }
				for(Subject sub:subjects) {
					ResultSet rs1 = stmt.executeQuery("SELECT * FROM book WHERE subjectid=" + sub.getSubjectId());
					 Set<Book> books=new HashSet<>();
					 while(rs1.next()) {
		   	             Book b=extractBookFromRS(rs1);
		   	             books.add(b);
		   			 }
					 sub.setReferences(books);
				}
				
				
			return subjects;
		} catch (SQLException ex) {
			ex.printStackTrace();
		}
		return subjects;
	}

}
