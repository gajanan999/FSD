package com.fsd.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.fsd.dao.SubjectDAO;
import com.fsd.entity.Subject;

@Controller
public class SubjectController {
	
	@Autowired
	SubjectDAO subjectDAO;

	@RequestMapping(value = "/deleteSubject", method = RequestMethod.POST)
	public String deleteSubject(@RequestParam("subjectId") int subjectId, Model model) throws IOException {
		boolean subjectDeleted=false;
		//subjectDeleted=databaseDAO.deleteSubject(subjectId);
		subjectDeleted=subjectDAO.deleteSubject(subjectId);
		
		if (subjectDeleted) {
			model.addAttribute("message", "Subject has been deleted");
		} else {
			model.addAttribute("message", "Subject not Found");
		}
		
		
		return "deleteSubject";
	}
	
	@RequestMapping(value = "/searchSubject", method = RequestMethod.POST)
	public String searchSubject(@RequestParam("subjectId") int subjectId, Model model) throws IOException {
		Subject sub=new Subject();
		Set<Subject> foundSubjects = new HashSet<>();
		sub=subjectDAO.searchSubject(subjectId);
		
		//sub=databaseDAO.searchSubject(subjectId);
		foundSubjects.add(sub);
		model.addAttribute("subjects", foundSubjects);
		return "searchSubject";
		
	}
	
	@RequestMapping(value = "/searchSubjectByDuration", method = RequestMethod.POST)
	public String searchSubjectByDuration(@RequestParam("durationInHours") int durationInHours, Model model) throws IOException {
		Subject sub=new Subject();
		List<Subject> foundSubjects = new ArrayList<>();
		
		foundSubjects=subjectDAO.searchSubjectByDuration(durationInHours);
		
		model.addAttribute("subjects", foundSubjects);
		return "searchSubject";
		
	}
	
}
